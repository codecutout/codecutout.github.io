﻿#light
module Main =
    open System
    open System.IO
    open System.Text

    type BrainfuckMachine (memSize) = 
        let mutable _ptr = 0
        let _memory = Array.zeroCreate<byte> memSize

        member this.Ptr 
            with get () = _ptr
            and set v = _ptr <- v 

        member this.Memory
            with get() = _memory

        member this.Value
            with get() = _memory.[_ptr]
            and set v = _memory.[_ptr] <- v
    

    let execute (filename:string) =
        //The sequence of characters from the file
        let charSeq = seq { 
            use sr = new StreamReader(filename);
            while not sr.EndOfStream do
                yield! sr.ReadLine().ToCharArray()
        }

        //helper method to allow a sequence given an enumerator. This allows
        //sequences to share a common enumerator but have the benefit of being
        //a sequence
        let sharedSeq (enumerator:Collections.Generic.IEnumerator<'a>) = seq {
            while enumerator.MoveNext () do
                yield enumerator.Current
        }

       

        
        //Converts the character sequence into a sequence of functions
        //The entire while block is considered one function
        let rec instructionSeq (instructions:seq<char>) = seq {
            let enumerator = instructions.GetEnumerator()
            
            while enumerator.MoveNext () && enumerator.Current <> ']' do
                yield match enumerator.Current with
                    | '>' -> fun (m:BrainfuckMachine) -> m.Ptr <- m.Ptr + 1
                    | '<' -> fun (m:BrainfuckMachine) -> m.Ptr <- m.Ptr - 1
                    | '+' -> fun (m:BrainfuckMachine) -> m.Value <-  m.Value + byte 1
                    | '-' -> fun (m:BrainfuckMachine) -> m.Value <- m.Value - byte 1
                    | '.' -> fun (m:BrainfuckMachine) -> Encoding.ASCII.GetChars([|m.Value|]).[0] |> Console.Write
                    | ',' -> fun (m:BrainfuckMachine) -> m.Value <- Encoding.ASCII.GetBytes([|Console.ReadKey().KeyChar|]).[0]
                    | '[' -> 
                        //gather up all the inner items to be executed later
                        let block = enumerator |> sharedSeq |> instructionSeq |> Seq.toList
                        fun(m:BrainfuckMachine) ->
                        
                            while m.Value <> byte 0 do
                                block |> Seq.iter (fun (f)->f m)
                    | _ -> fun (m:BrainfuckMachine) -> () //the only reason yield! is used so so we can return nothing here
              
        }

        //create a machine with some memory
        let BrainfuckMachine = new BrainfuckMachine 30000
    
        //pipe our sequence of characters to get a sequence of methods and execute each method in turn
        charSeq |> instructionSeq |> Seq.iter (fun (f)->f BrainfuckMachine)    
    
        //hold the screen so we can see some result
        Console.WriteLine ()
        Console.WriteLine "press any key to exit"
        Console.ReadKey() |> ignore
        0




    [<EntryPoint>]
    let main (args:string[]) =
        match args with
        | [|_|] ->
           execute args.[0] 
        | _ ->
            Console.WriteLine("Usage: BrainfuckInterpreter.exe [BrainfuckFile.b]")
            -1    

