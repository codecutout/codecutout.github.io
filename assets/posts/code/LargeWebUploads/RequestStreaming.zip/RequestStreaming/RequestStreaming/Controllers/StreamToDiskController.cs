﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;

namespace RequestStreaming.Controllers
{
    public class StreamToDiskController : IController
    {
		public static string FileDirectory = @"C:\Temp";

		public void Execute(System.Web.Routing.RequestContext requestContext)
		{
			//unfortunatly the MVC request object doesnt have GetBufferlessInputStream
			//so we have to bypass and go directly to the static httpcontext
			using (var requestStream = HttpContext.Current.Request.GetBufferlessInputStream())
			{

				var mpp = new MultipartPartParser(requestStream);

				while (mpp != null && !mpp.IsEndPart && !string.IsNullOrWhiteSpace(mpp.Filename))
				{
					//we can access the filename from the part

					Directory.CreateDirectory(FileDirectory);
					string fileName = Path.Combine(FileDirectory, mpp.Filename);

					//we can access the part contents as a stream and copy it
					//to a file stream, or any other writable stream
					using (var fileStream = new FileStream(fileName, FileMode.CreateNew, FileAccess.Write))
					{
						mpp.CopyTo(fileStream);
					}

					//move the stream foward until we get to the next part
					mpp = mpp.ReadUntilNextPart();
				}

				requestContext.HttpContext.Response.Redirect("/");
			}
		}
	}
}
