﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Proxy;


namespace ConfigReader
{
    class Program
    {
        static void Main(string[] args)
        {
            ISettings settings = DynamicProxy.New<ISettings>((i,p)=>ReadConfigSetting(i,p));


            Console.WriteLine(string.Format("ApplicationName = {0}", settings.ApplicationName));
            Console.WriteLine(string.Format("Version = {0}", settings.Version));
            Console.WriteLine(string.Format("CacheSettings.UserCacheSize = {0}", settings.CacheSettings.UserCacheSize)); 
            Console.ReadKey();
        }

        public static object ReadConfigSetting(MethodInfo info, object[] param, IEnumerable<string> path = null)
        {
           

            if (!info.IsGetProperty())
                throw new Exception("Unable to execute " + info.Name);

            PropertyInfo property = info.GetProperty();

            //append the name of our property onto the path
            var newPath = new List<string>(path ?? new string[0]);
            newPath.Add(property.Name);
            path = newPath;

            if(property.PropertyType.IsInterface){
               
                return DynamicProxy.New(property.PropertyType, (i, p) => ReadConfigSetting(i, p, newPath));
            }

            string appSettingValue = ConfigurationManager.AppSettings[string.Join(".", path)];
            if (appSettingValue == null)
                return null;

            var descriptor = TypeDescriptor.GetConverter(property.PropertyType);
            return descriptor.ConvertFromInvariantString(appSettingValue);
        }
    }

    public interface ISettings
    {
        string ApplicationName { get; }

        int Version { get; }

        ICacheSettings CacheSettings { get; }
    }

    public interface ICacheSettings
    {
        int ProductCacheSize {get;}
        int UserCacheSize {get;}
    }
}
