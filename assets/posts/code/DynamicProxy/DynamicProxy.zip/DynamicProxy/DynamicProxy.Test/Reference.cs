﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy.Test
{
    class Reference
    {
        public int TestMethod()
        {
            if (Add(1, 2) == null)
                return default(int);

            return 0;
        }

        public object Add(int a, int b)
        {
            return null;
        }

        public DateTime ReturnDefaultx()
        {
            return new DateTime();
        }

        public void ReturnRef(ref DateTime dt)
        {
            DateTime myDt = new DateTime(2000, 1, 1);
            dt = myDt;

        }
    }
}
