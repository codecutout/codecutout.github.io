﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Proxy;

namespace TestEmitProxy
{
    public abstract class Greeter
    {
        public abstract string Name { get; }

        public string Greet(string hello)
        {
            return hello + " my name is " + Name;
        }

    }

    public interface IAnimal
    {
        DateTime BirthDate { get; set; }

        void Sleep(int time);
    }

    public abstract class Mammal : IAnimal
    {
        public abstract string HairColor { get; }

        public bool NurseYoung(){
            return true;
        }

        public abstract void Sleep(int time);

        public DateTime BirthDate { get; set; }

    }

   

  

   

    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class TestAbstractProxy
    {
        [TestMethod]
        public void TestSimpleProxy()
        {
            Greeter person = DynamicProxy.New<Greeter>((info, param) =>
            {
                return "Jacob";
            });

            Assert.AreEqual("Ahoy my name is Jacob", person.Greet("Ahoy"));
        }

        [TestMethod]
        public void TestAbstractWithInterfaceProxy()
        {
            Mammal giraffe = DynamicProxy.New<Mammal>((info, param) =>
            {
                if (info.Name.Contains("HairColor"))
                    return "Orange";
                if (info.Name.Contains("Sleep"))
                {
                    Assert.AreEqual(1, param[0]);
                    return null;
                }

                Assert.Fail("Property " + info.Name + " should not be implmented");
                return null;
            });

            //test abstract methods
            Assert.AreEqual("Orange", giraffe.HairColor);
            giraffe.Sleep(1);

            //test non abstract methods
            giraffe.BirthDate = new DateTime(2005, 1, 1);
            Assert.AreEqual(new DateTime(2005, 1, 1), giraffe.BirthDate);
            Assert.IsTrue(giraffe.NurseYoung());

           
        }

      

    }
}
