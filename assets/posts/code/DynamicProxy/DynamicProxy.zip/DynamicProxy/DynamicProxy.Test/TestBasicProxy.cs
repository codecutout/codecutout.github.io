﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Proxy;
using System.ComponentModel;

namespace TestEmitProxy
{
    public interface ISpeaker
    {
        [DefaultValue("Hi")]
        string Say(string words);
    }

    public interface IPerson : ISpeaker
    {
        [DefaultValue("Speaker")]
        string Name { get; set; }
    }

    public interface ITeacher : IPerson
    {
        bool Teach(string subject);
    }

    public interface IActor : ISpeaker
    {
        void Act();
    }

    public interface ICalculator
    {
        int Add(int a, int b);
        long Add(long a, long b);
        float Add(float a, float b);
        double Add(double a, double b);
        DateTime Add(DateTime a, TimeSpan b);

       
    }

  

   

    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class TestBasicProxy
    {
        [TestMethod]
        public void TestSimpleProxy()
        {
            ISpeaker person = DynamicProxy.New<ISpeaker>((info, param) =>
            {
                return "Proxy Says '" + param[0] + "'";
            });

            Assert.AreEqual("Proxy Says 'Hello'", person.Say("Hello"));
        }

        [TestMethod]
        public void TestProperties()
        {
            string setValue = null;
            IPerson person = DynamicProxy.New<IPerson>((info, param) =>
            {
                Assert.AreEqual("Name", info.GetProperty().Name); 
                if(info.IsGetProperty())
                    return "ProxyMan";
                else if(info.IsSetProperty())
                    setValue = param[0] as string;
                return null;
            });
            person.Name = "John";
            Assert.AreEqual("ProxyMan", person.Name);
            Assert.AreEqual("John", setValue);
        }

        [TestMethod]
        public void TestAttributes()
        {
            IPerson person = DynamicProxy.New<IPerson>((info, param) =>
            {
                var propInfo = info.GetProperty();
                if(propInfo != null)
                    return propInfo.GetCustomAttributes(typeof(DefaultValueAttribute), true).OfType<DefaultValueAttribute>().First().Value;
                else
                    return info.GetCustomAttributes(typeof(DefaultValueAttribute), true).OfType<DefaultValueAttribute>().First().Value;
    

            });
            Assert.AreEqual("Hi", person.Say(""));
            Assert.AreEqual("Speaker", person.Name);
        }

        [TestMethod]
        public void TestInheritence()
        {
            bool success = false;


            ITeacher teacher = Proxy.DynamicProxy.New<ITeacher>((info, param) =>
            {
                if (info.Name == "Teach")
                    success = true;
                return true;
            });

            Assert.IsFalse(success);
            Assert.AreEqual(true, teacher.Teach("C#"));
            Assert.IsTrue(success);

        }


        [TestMethod]
        public void TestVoidReturnValue()
        {
            bool success = false;


            var actor = DynamicProxy.New<IActor>((info, param) =>
            {
                Assert.IsTrue(param.Length == 0);
                success = true;
                return new List<String>();
            });

            actor.Act();
            Assert.AreEqual(true, success);


        }

        [TestMethod]
        [ExpectedException(typeof(InvalidCastException))]
        public void TestIncorrectReturnValue()
        {
            var actor = DynamicProxy.New<IActor>((info, param) =>
            {
                return new List<String>();
            });

            var test = actor.Say("Hello");
        }

        [TestMethod]
        public void TestBoxingValue()
        {
            var calc = DynamicProxy.New<ICalculator>((info, param) =>
            {
                if(info.ReturnType == typeof(int))
                    return (int)param[0] + (int)param[1];
                if (info.ReturnType == typeof(long))
                    return (long)param[0] + (long)param[1];
                if (info.ReturnType == typeof(double))
                    return (double)param[0] + (double)param[1];
                if (info.ReturnType == typeof(float))
                    return (float)param[0] + (float)param[1];
                 if (info.ReturnType == typeof(DateTime))
                     return (DateTime)param[0] + (TimeSpan)param[1];
                 return null;
            });

            Assert.AreEqual(5, calc.Add(2, 3));
            Assert.AreEqual(5L, calc.Add(2L, 3L));
            Assert.AreEqual(5.5, calc.Add(2.2, 3.3));
            Assert.AreEqual(5.5f, calc.Add(2.2f, 3.3f));
            Assert.AreEqual(new DateTime(2000, 2, 5), calc.Add(new DateTime(2000, 2, 3), new TimeSpan(2,0,0,0)));
        }

        [TestMethod]
        public void TestDefaultingNullValue()
        {
            var calc = DynamicProxy.New<ICalculator>((info, param) =>
            {
               return null;
            });

            Assert.AreEqual(0, calc.Add(2, 3));
            Assert.AreEqual(0L, calc.Add(2L, 3L));
            Assert.AreEqual(0D, calc.Add(2.2, 3.3));
            Assert.AreEqual(0f, calc.Add(2.2f, 3.3f));
            Assert.AreEqual(new DateTime(), calc.Add(new DateTime(2000, 2, 3), new TimeSpan(2, 0, 0, 0)));
        }

    }
}
