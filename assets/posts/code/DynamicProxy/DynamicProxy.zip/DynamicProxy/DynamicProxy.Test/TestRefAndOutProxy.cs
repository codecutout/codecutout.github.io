﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Proxy;

namespace TestEmitProxy
{

    public interface IDivider
    {
        int Divide(int dividend, int divisor, out int remainder);
    }

    public interface IRef
    {
        void Increment(ref int a);
    }

    public interface IObjectOut
    {
        void Create(out StringBuilder a);
    }

    public interface IObjectRef
    {
        void Duplicate(ref StringBuilder a);
    }

    public interface IRefAndOut
    {
        //void Randit(ref DateTime b);
        void Randit(ref int a, ref DateTime b, ref StringBuilder c, out int d, out DateTime e, out StringBuilder f);
    }

   

    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class TestProxy
    {
       

        [TestMethod]
        public void TestOutParameters()
        {
            var calc = DynamicProxy.New<IDivider>((info, param) =>
            {
                int a = (int)param[0];
                int b = (int)param[1];
                Assert.IsNull(param[2], "Out parameter should come through as null");
                param[2] = a % b;
                return a / b;

            });
            int remainder = 100;
            Assert.AreEqual(6, calc.Divide(40,6, out remainder));
            Assert.AreEqual(4, remainder);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void TestUnSetOutParameters()
        {
            var calc = DynamicProxy.New<IDivider>((info, param) =>
            {
                int a = (int)param[0];
                int b = (int)param[1];
                return a / b;

            });
            int remainder;
            Assert.AreEqual(6, calc.Divide(40, 6, out remainder));
        }

        [TestMethod]
        public void TestObjectOutParameters()
        {
            var obj = DynamicProxy.New<IObjectOut>((info, param) =>
            {
                param[0] = new StringBuilder("Hi");
                return null;
            });

            var a = new StringBuilder("Echo");
            obj.Create(out a);
            Assert.AreEqual("Hi", a.ToString());

        }

        [TestMethod]
        public void TestObjectOutUnSetParameters()
        {
            var obj = DynamicProxy.New<IObjectOut>((info, param) =>
            {
                return null;
            });

            var a = new StringBuilder("Echo");
            obj.Create(out a);
            Assert.IsNull(a);

        }


        [TestMethod]
        public void TestRefParameters()
        {
            var obj = DynamicProxy.New<IRef>((info, param) =>
            {
                Assert.AreEqual(10, param[0]);
                param[0] = ((int)param[0])+1;

                return null;
            });

            var a = 10;
            obj.Increment(ref a);
            Assert.AreEqual(11, a);

        }

        [TestMethod]
        public void TestObjectRefParameters()
        {
            var obj = DynamicProxy.New<IObjectRef>((info, param) =>
            {
                Assert.AreEqual("Echo", param[0].ToString());
                var builder = (StringBuilder)param[0];
                builder.Append(builder.ToString());
                return null;
            });

            var a = new StringBuilder("Echo");
            obj.Duplicate(ref a);
            Assert.AreEqual("EchoEcho", a.ToString());

        }

        [TestMethod]
        public void TestOutAndRefParameters()
        {
            var obj = DynamicProxy.New<IRefAndOut>((info, param) =>
            {
                Assert.AreEqual(10, param[0]);
                Assert.AreEqual(new DateTime(2010, 1, 31), param[1]);
                Assert.AreEqual("C", ((StringBuilder)param[2]).ToString());
                Assert.IsNull(param[3], "Out parameter should come through as null");
                Assert.IsNull(param[4], "Out parameter should come through as null");
                Assert.IsNull(param[5], "Out parameter should come through as null");

                param[0] = 20;
                param[2] = new StringBuilder("C2");

                param[3] = 200;
                param[4] = new DateTime(1990, 1, 1);
                param[5] = null;


                return null;
            });
            var a = 10;
            var b = new DateTime(2010, 1, 31);
            var c = new StringBuilder("C");

            var d = 100;
            var e = new DateTime(2000, 1, 1);
            var f = new StringBuilder("f");

            obj.Randit(ref a, ref b, ref c, out d, out e, out f);
            //obj.Randit(ref e);

            Assert.AreEqual(20, a);
            Assert.AreEqual(new DateTime(2010, 1, 31), b);
            Assert.AreEqual("C2", c.ToString());

            Assert.AreEqual(200, d);
            Assert.AreEqual(new DateTime(1990, 1, 1), e);
            Assert.IsNull(f);



        }




      
    }
}
